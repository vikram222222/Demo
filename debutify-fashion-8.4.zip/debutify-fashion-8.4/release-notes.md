# 🚀 Debutify 8.4 Release Update

Debutify 8.4 is all about flexibility and better control — with brand-new sections, smarter discount logic, enhanced theme blocks, and important layout fixes. From easier discount management to advanced testimonials, this version helps merchants build trust and optimize conversions.

## 🆕 New Sections

- 🧱 Custom Column  
  Build flexible column layouts to organize and present content more effectively.
  
   **🧱 Supported Blocks**

  This section allows you to design flexible, responsive layouts using the following supported blocks:

  #### 📄 Text & Layout

  - **`title`**  
  Highlight key headings to guide customer focus across your page.

  - **`caption`**  
    Add short, compelling text snippets to engage your visitors effectively.

  - **`description`**  
    Provide detailed information with versatile styling options.

  - **`bullet points`**  
    Showcase features or benefits using a clear and concise list format.

  - **`tabs`**  
    Organize detailed information across multiple clickable tabs.

  - **`faq`**  
    Answer common questions in an expandable, interactive format.

  - **`single button`**  
    Add a standalone call-to-action button to drive specific actions.

  - **`double button`**  
    Provide two CTA options side-by-side, now with Add to Cart functionality.

  #### 🖼️ Visual & Media

  - **`image`**  
    Showcase your products or features with attention-grabbing visuals.

  - **`icon`**  
    Use icons to highlight key features and simplify messaging.

  - **`icon with text`**  
    Pair icons with descriptive text to create visually appealing layouts.

  - **`icon-with-image`**  
    Combine icons and images for even greater visual impact.

  - **`video`**  
    Embed videos to communicate your message or demo products effectively.

  - **`product media`**  
    Showcase product images or videos directly in the section.

  #### 🛍️ Product Elements

  - **`product title`**  
    Display the product name prominently.

  - **`product price`**  
    Show prices, including discounts and compare-at prices.

  - **`product inventory`**  
    Inform customers about stock availability in real-time.

  - **`sku`**  
    Display the Stock Keeping Unit for inventory tracking.

  - **`rating`**  
    Highlight product ratings to build credibility.

  - **`product variant picker`**  
    Allow users to select product variants directly.

  - **`quantity selector`**  
    Enable full-width or compact quantity input options.

  - **`buy buttons`**  
    Add customizable Buy Now or Add to Cart buttons.

  - **`product share`**  
    Include sharing options for social platforms.

  - **`size chart`**  
    Provide detailed size information with a customizable chart.

  - **`quantity break`**  
    Encourage bulk buying with tiered pricing information.

  - **`upsell`**  
    Suggest related products to increase cart value.

  - **`product complementary`**  
    Recommend complementary products or services.

  - **`customizable`**  
    Add fully customizable content blocks for unique layouts.

  This section empowers merchants to build their own modular promotional or product blocks with complete creative freedom.

- 🎞️ Image/Video Slider  
  Showcase multiple product images and videos in a sleek, interactive slider.

- 🛠️ Product Features  
  Highlight key selling points of a product using icons and text in a clean layout.

- 👍 Facebook Testimonial  
  Showcases social proof from Facebook comments and reviews.

- 🌟 Trustpilot Reviews  
  Display verified customer reviews directly on the storefront.

## ✨ Feature Improvements

- 📨 Newsletter  
  Added a **Minimal Form** option for a cleaner and more compact design.

- 🔄 Auto Discount Logic  
  Discounts now apply from a single centralized system — simplifying setup and ensuring correct discount rules.  
  New setting added to enable or disable auto-discount functionality.

- ➕ Advanced Double Button Block  
  New block supports dual CTA buttons with `Add to Cart` action included for more flexible layouts.

- 📝 Description Block  
  Improved formatting and layout handling for better content presentation.

- 🧩 Custom Liquid Section  
  New option to show or hide section on sections for more control.

- 🔀 Widget Group  
  Widgets are now converted to a **JSON group structure** for improved configurability and performance.

- 🛍️ Buy Buttons  
  - Widgets now support direct feature control from the block itself for faster edits.

- 🧠 Discount Logic  
  - All automatic discount handling is now centralized, reducing errors and simplifying management.  
  - Added admin toggle to enable/disable automatic discount application.

## 🐞 Bug Fixes

- 🧭 Mega Menu  
  Fixed layout and positioning issues in certain screen sizes.

- 🛒 Quick Add Block  
  Resolved issue where the block was appearing in the footer unexpectedly.

- 🔍 Product Zoom  
  Zoom functionality now works correctly on the **Single Product** page.

- 🧰 Help Center  
  - Fixed issue where the widget was not appearing as expected.

- 🔤 Variant Picker  
  - Resolved conflict between small and capital letters in variant values.

- 🖼️ Single Product Page  
  - Fixed image ratio display issue.  
  - Corrected zoom option alignment and interaction.

- 📂 Mega Menu  
  - Addressed rendering and layout issues in desktop view.

- 🛒 Quick Add  
  - Fixed layout bug where the quick add block appeared in the footer unintentionally.

- 🛒 Sticky Add to Cart
  - Fixed issue where the sticky add to cart bar wasn’t working properly.
    
- 🖼️ Image with Text 
  - *Image with Text Parallax* setting is now available under **Theme Settings**.  
- 🔍 Product Page 
  - Resolved zooming issue affecting product images.

## 🔗 Integrations

- **Referrals Support Added** for:
  - 🎁 BOGOS
  - 🧠 WizAI
  - 📈 UpPromote